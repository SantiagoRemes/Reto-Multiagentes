using System.Collections;
using System.Collections.Generic;
using UnityEngine.Networking;

using SimpleJSON;
using UnityEngine;
using System.Linq;


public struct RobotData
{
    public Vector3 initialPosition;
    public List<Vector3> targetPositions; 
}

public struct CrateData
{
    public Vector3 initialPosition;
    public List<Vector3> targetPositions;
}

public struct CrateInfo
{
    public int id;
    public CrateData crateData;
}

public class Controller : MonoBehaviour
{

    
    private Queue<CrateInfo> pendingCrates;

    public GameObject robotPrefab;
    public GameObject estantesPrefab;
    public GameObject pilasPrefab;
    public GameObject bandasPrefab;
    public GameObject cratePrefab; 

   

    public static GameObject[] robots;
    public static GameObject[] estantes;
    public static GameObject[] pilas;
    public static GameObject[] bandasEntrada;
    public static GameObject[] bandasSalida;
    public static GameObject[] crates;
    


    void Start()
    {

        LoadRobots();
        LoadPilas();
        LoadBandasEntrada();
        LoadBandasSalida();
        LoadEstantes();
        LoadCrates();
    
    }



    public void LoadRobots()
    {
        robots = new GameObject[GlobalVariables.numRobots];

        for (int i = 0; i < GlobalVariables.numRobots; i++)
        {
            int robotId = i + 1;
            if (GlobalVariables.robotsData.TryGetValue(robotId, out RobotData robotData))
            {
                GameObject robotObject = Instantiate(robotPrefab, robotData.initialPosition, Quaternion.Euler(0, 0, 0));
                Robot robotScript = robotObject.AddComponent<Robot>();
                robotScript.id = robotId;
                robotScript.SetTargetPositions(robotData.targetPositions);
                robots[i] = robotObject;
            }
            else
            {
                Debug.LogError("Robot data not found for ID: " + robotId);
            }
        }
        
    }

    public void LoadPilas()
    {
        pilas = new GameObject[GlobalVariables.numPilas];

        for (int i = 0; i < GlobalVariables.numPilas; i++)
        {
            Vector3 position = GlobalVariables.posPilas[i];
            pilas[i] = Instantiate(pilasPrefab, position, Quaternion.identity);
        }
    }

    public void LoadBandasEntrada()
    {
        bandasEntrada = new GameObject[GlobalVariables.numBandasEntrada];

        for (int i = 0; i < GlobalVariables.numBandasEntrada; i++)
        {
            Vector3 position = GlobalVariables.posBandasEntrada[i];
            bandasEntrada[i] = Instantiate(bandasPrefab, position, Quaternion.Euler(0, -90, 0));
        }
    }

    public void LoadBandasSalida()
    {
        bandasSalida = new GameObject[GlobalVariables.numBandasSalida];

        for (int i = 0; i < GlobalVariables.numBandasSalida; i++)
        {
            Vector3 position = GlobalVariables.posBandasSalida[i];
            bandasSalida[i] = Instantiate(bandasPrefab, position, Quaternion.Euler(0, 90, 0));
        }
    }

    public void LoadEstantes()
    {
        estantes = new GameObject[GlobalVariables.numEstantes];

        for (int i = 0; i < GlobalVariables.numEstantes; i++)
        {
            Vector3 position = GlobalVariables.posEstantes[i];
            estantes[i] = Instantiate(estantesPrefab, position, Quaternion.identity);
        }
    }

    public void LoadCrates()
    {
        crates = new GameObject[GlobalVariables.numCrates];

        for (int i = 0; i < GlobalVariables.numCrates; i++)
        {
            int crateId = i + 1;
            if (GlobalVariables.cratesData.TryGetValue(crateId, out CrateData crateData))
            {
                GameObject crateObject = Instantiate(cratePrefab, crateData.initialPosition, Quaternion.identity);

                Crate crateScript = crateObject.AddComponent<Crate>();
                crateScript.id = crateId;
                crateScript.SetTargetPositions(crateData.targetPositions);

                crates[i] = crateObject;
            }
            else
            {
                Debug.LogError("Crate data not found for ID: " + crateId);
            }
        }
    }

}