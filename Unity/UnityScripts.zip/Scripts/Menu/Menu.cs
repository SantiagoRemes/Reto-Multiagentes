using System.Collections;
using System.Collections.Generic;
using UnityEngine.Networking;
using UnityEngine.SceneManagement;
using UnityEngine;
using SimpleJSON;
using TMPro;

public static class GlobalVariables
{
    public static int numRobots;
    public static Dictionary<int, RobotData> robotsData = new Dictionary<int, RobotData>(); 

    public static int numCrates;
    public static Dictionary<int, CrateData> cratesData = new Dictionary<int, CrateData>();
    


    public static int numEstantes;
    public static List<Vector3> posEstantes = new List<Vector3>();

    public static int numPilas;
    public static List<Vector3> posPilas = new List<Vector3>();

    public static int numBandasEntrada;
    public static List<Vector3> posBandasEntrada = new List<Vector3>();
    public static int numBandasSalida;
    public static List<Vector3> posBandasSalida = new List<Vector3>();

    // Method to initialize from JSON
     public static void InitializeFromJSON(string jsonString)
    {
        var json = JSON.Parse(jsonString);

        // Parse number of robots
        numRobots = json["numRobots"].AsInt;
        foreach (JSONNode robotNode in json["robots"].AsArray)
        {
            int id = robotNode["id"].AsInt + 1;
            Vector3 initialPos = new Vector3(
                robotNode["initialPosition"]["x"].AsFloat,
                robotNode["initialPosition"]["y"].AsFloat,
                robotNode["initialPosition"]["z"].AsFloat
            );

            List<Vector3> targets = new List<Vector3>();
            foreach (JSONNode targetNode in robotNode["targetPositions"].AsArray)
            {
                Vector3 targetPos = new Vector3(
                    targetNode["x"].AsFloat,
                    targetNode["y"].AsFloat,
                    targetNode["z"].AsFloat
                );
                
                targets.Add(targetPos);
                
            }

            robotsData[id] = new RobotData { initialPosition = initialPos, targetPositions = targets };
           

        }

        //numCrates = json["numCrates"].AsInt + 3;
        int maxCrateId = 0;
        foreach (JSONNode crateNode in json["crates"].AsArray)
        {
            
            int id = crateNode["id"].AsInt + 1;
            Vector3 initialPos = new Vector3(
                crateNode["initialPosition"]["x"].AsFloat + .5f,
                crateNode["initialPosition"]["y"].AsFloat - 0.38f, // used to be -0.16
                crateNode["initialPosition"]["z"].AsFloat + 1.1f // used to be +0.6
            );

            List<Vector3> targets = new List<Vector3>();
            foreach (JSONNode targetNode in crateNode["targetPositions"].AsArray)
            {
                Vector3 targetPos = new Vector3(
                    targetNode["x"].AsFloat + .5f,
                    targetNode["y"].AsFloat -0.38f, // used to be -0.16
                    targetNode["z"].AsFloat +1.1f // used to be +0.6
                );
                targets.Add(targetPos);
            }

        cratesData[id] = new CrateData { initialPosition = initialPos, targetPositions = targets };
        if (id > maxCrateId)
        {
            maxCrateId = id;
        }
    }
         numCrates = maxCrateId;

        numEstantes = json["numEstantes"].AsInt;
        foreach (JSONNode node in json["posEstantes"].AsArray)
        {
            posEstantes.Add(new Vector3(node["x"].AsFloat, node["y"].AsFloat + 0.778f, node["z"].AsFloat + 1.1f));
        }

        // Parse pilas data
        numPilas = json["numPilas"].AsInt;
        foreach (JSONNode node in json["posPilas"].AsArray)
        {
            posPilas.Add(new Vector3(node["x"].AsFloat +0.2f, node["y"].AsFloat + 2f, node["z"].AsFloat = 4.32f));
        }

        // Parse bandas entrada data
        numBandasEntrada = json["numBandasEntrada"].AsInt;
        foreach (JSONNode node in json["posBandasEntrada"].AsArray)
        {
            posBandasEntrada.Add(new Vector3(node["x"].AsFloat + 5f, node["y"].AsFloat +0.39f/*+ 0.6f*/, node["z"].AsFloat + 0.7f));
        }

        //Banda Salida
        numBandasSalida = json["numBandasSalida"].AsInt;
        foreach (JSONNode node in json["posBandasSalida"].AsArray)
        {
            posBandasSalida.Add(new Vector3(node["x"].AsFloat - 5f, node["y"].AsFloat+ +0.39f, node["z"].AsFloat + 0.7f));
        }

    }

        public static void Reset()
    {
        numRobots = 0;
        robotsData.Clear(); 

        numCrates = 0;
        cratesData.Clear();

        numEstantes = 0;
        posEstantes.Clear();

        numPilas = 0;
        posPilas.Clear();

        numBandasEntrada = 0;
        posBandasEntrada.Clear();

        numBandasSalida = 0;
        posBandasSalida.Clear();
    }
}

public class Menu : MonoBehaviour
{
    public TextMeshProUGUI RobotsNum, EstanciasNum, PilasNum, CratesNum, Titulo;

    public TMP_InputField StepNumberInput;
    public TMP_InputField StepsPerPackageGenerationInput;
    public TMP_InputField StepsCreateOrderInput;
    public TMP_InputField numAgentesInput;

    private int stepNumber = 50;
    private int numAgentes = 5;
    private int stepsPerPackageGeneration = 7;
    private int stepsCreateOrder = 10;
    private bool loaded = false;

    void Start()
    {
        Titulo.text = "Loading...";
        RobotsNum.text = "Robots: #";
        EstanciasNum.text = "Estantes: #";
        PilasNum.text = "Pilas: #" ;
        CratesNum.text = "Cajas: #";

        StepNumberInput.text = stepNumber.ToString();
        StepsPerPackageGenerationInput.text = stepsPerPackageGeneration.ToString();
        StepsCreateOrderInput.text = stepsCreateOrder.ToString();
        numAgentesInput.text = numAgentes.ToString();

        StartCoroutine(LoadJSONDataFromAPI());
    }

    public void onIniciar(){



        StartCoroutine(LoadJSONDataFromAPI());
        // if (loaded){
        //     SceneManager.LoadScene("Scenes/SampleScene");
        // loaded = false;
        // }
    }
 
    IEnumerator LoadJSONDataFromAPI()
    {
        // string apiUrl = "http://localhost:8585/?M=40&N=50&num_agentes=8&steps_per_package_generation=7&steps_create_order=15&num_steps=50"; 
        // UnityWebRequest request = UnityWebRequest.Get(apiUrl);
        // yield return request.SendWebRequest();

        string apiUrl = $"http://localhost:8585/?M=40&N=50&num_agentes={numAgentes}&steps_per_package_generation={stepsPerPackageGeneration}&steps_create_order={stepsCreateOrder}&num_steps={stepNumber}"; 
        UnityWebRequest request = UnityWebRequest.Get(apiUrl);
        yield return request.SendWebRequest();

        if (request.isNetworkError || request.isHttpError)
        {
            Debug.LogError(" Server Error: " + request.error);
        }
        else
        {
            string jsonResponse = request.downloadHandler.text;
            GlobalVariables.InitializeFromJSON(jsonResponse);
            UpdateUIFromGlobalVariables();
            Debug.Log("Data is successfully loaded and parsed.");

        }
        // loaded = true;
        // Invoke("LoadScene", 2.0f); 
        // SceneManager.LoadScene("Scenes/SampleScene");

    }

             
      

    private void LoadScene() {
        SceneManager.LoadScene("Scenes/SampleScene");
    }

    public void Refresh()
    {
        OnStepNumberChanged();
        OnStepsPerPackageGenerationChanged();
        OnStepsCreateOrderChanged();
         numAgentesChanged();
       // Debug.Log($"Refreshed values: Step Number = {stepNumber}, Steps Per Package Generation = {stepsPerPackageGeneration}, Steps Create Order = {stepsCreateOrder}");
        Titulo.text = "Loading...";
        RobotsNum.text = "Robots:";
        EstanciasNum.text = "Estantes: #";
        PilasNum.text = "Pilas: #" ;
        CratesNum.text = "Cajas: #";
        StartCoroutine(LoadJSONDataFromAPI());

    }

    private void UpdateUIFromGlobalVariables()
    {
        Titulo.text = "NJ3 Simulación";
        RobotsNum.text = "Robots: " ;//+ GlobalVariables.numRobots.ToString();
        EstanciasNum.text = "Estantes: " + GlobalVariables.numEstantes.ToString();
        PilasNum.text = "Pilas: " + GlobalVariables.numPilas.ToString();
        CratesNum.text = "Cajas: " + GlobalVariables.numCrates.ToString();
    }

    public void OnStepNumberChanged()
    {
        if (int.TryParse(StepNumberInput.text, out int value))
        {
            stepNumber = value;
        }
    }

    public void numAgentesChanged()
    {
        if (int.TryParse(numAgentesInput.text, out int value))
        {
            numAgentes = value;
        }
    }

    public void OnStepsPerPackageGenerationChanged()
    {
        if (int.TryParse(StepsPerPackageGenerationInput.text, out int value))
        {
            stepsPerPackageGeneration = value;
        }
    }

    public void OnStepsCreateOrderChanged()
    {
        if (int.TryParse(StepsCreateOrderInput.text, out int value))
        {
            stepsCreateOrder = value;
        }
    }

}

