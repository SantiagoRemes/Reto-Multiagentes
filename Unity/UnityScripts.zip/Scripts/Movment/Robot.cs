using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class Robot : MonoBehaviour
{
    public int id;
    public List<Vector3> targetPositions;
    private int currentTargetIndex;
    public float speed = 2.0f;
    public float movementDuration = 0.1f; 

    private float startTime;
    private bool Running = true;
    private int temp =1;

    void Start()
    {
        currentTargetIndex = 0;
        if (targetPositions.Count > 0)
        {
            StartMovement();
        }
    }

    void Update()
    {
        if (targetPositions.Count == 0) return;

        MoveToTarget();
        if (!Running && id == 1 && temp == 1) {
            temp = 0;
            Invoke("LoadExitMenuScene", 1.0f); 
        }
        //temp = 0;
    }

    void LoadExitMenuScene() {
        SceneManager.LoadScene("Scenes/ExitMenu");
    }

    private void MoveToTarget()
    {
        if (currentTargetIndex < targetPositions.Count)
        {
            Vector3 targetPosition = targetPositions[currentTargetIndex];
            float fractionOfJourney = (Time.time - startTime) / movementDuration;
            transform.position = Vector3.Lerp(transform.position, targetPosition, fractionOfJourney);

            if (fractionOfJourney >= 1.0f)
            {
                currentTargetIndex++;
                if (currentTargetIndex < targetPositions.Count)
                {
                    StartMovement();
                }else{
                    
                    Running= false;
                }
            }
        }
    }

    private void StartMovement()
    {
        startTime = Time.time;
        if (currentTargetIndex >= targetPositions.Count)
        {
            currentTargetIndex = 0;
        }
    }

    public void SetTargetPositions(List<Vector3> positions)
    {
        targetPositions = positions;
        currentTargetIndex = 0;
        if (positions.Count > 0)
        {
            StartMovement();
        }
    }
}
