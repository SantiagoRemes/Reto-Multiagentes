using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Crate : MonoBehaviour
{
    public int id;
    public List<Vector3> targetPositions;
    private int currentTargetIndex;
    public bool isMovingIndependently = true;
    public float speed = 2.0f;
    public float movementDuration = 0.1f; 
    private float startTime;
    private Controller controller;
    void Start()
    {
        currentTargetIndex = 0;
        controller = FindObjectOfType<Controller>(); 
        if (targetPositions.Count > 0)
        {
            StartMovement();
        }
    }

    void Update()
    {
        if (targetPositions.Count == 0) return;

        if (isMovingIndependently)
        {
            MoveToTarget();
        }
    }

    private void MoveToTarget()
    {
        if (currentTargetIndex < targetPositions.Count)
        {
            Vector3 targetPosition = targetPositions[currentTargetIndex];
            float fractionOfJourney = (Time.time - startTime) / movementDuration;
            transform.position = Vector3.Lerp(transform.position, targetPosition, fractionOfJourney);

            if (fractionOfJourney >= 1.0f)
            {
                currentTargetIndex++;
                if (currentTargetIndex < targetPositions.Count)
                {
                    StartMovement();
                }
                else
                {
                    OnReachedFinalPosition();
                }
            }
        }
    }

    private void StartMovement()
    {
        startTime = Time.time;
        if (currentTargetIndex >= targetPositions.Count)
        {
            currentTargetIndex = 0;
        }
    }


    private void OnReachedFinalPosition()
    {
        if (targetPositions.Count > 0)
        {
            float finalTargetX = targetPositions[targetPositions.Count - 1].x;
            float xThreshold = 2.0f; // Define esto con valor x de bandas de salida, si van a cambiar de poscicon
            if (finalTargetX < xThreshold)
            {
                Destroy(gameObject);
            }
            else{
            }
        }
    }


    public void SetTargetPositions(List<Vector3> positions)
    {
        targetPositions = positions;
        currentTargetIndex = 0;
        if (positions.Count > 0)
        {
            StartMovement();
        }
    }
}
